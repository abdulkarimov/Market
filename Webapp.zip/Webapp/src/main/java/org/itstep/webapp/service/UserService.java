package org.itstep.webapp.service;

import org.itstep.webapp.entity.DbUser;
import org.itstep.webapp.entity.Role;
import org.springframework.security.core.userdetails.UserDetailsService;

import java.util.List;

public interface UserService extends UserDetailsService {

 List<DbUser> getUser();
  DbUser registerUser(DbUser user);

}
