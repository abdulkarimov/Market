package org.itstep.webapp.service.impl;

import org.itstep.webapp.entity.DbUser;
import org.itstep.webapp.entity.Role;
import org.itstep.webapp.repository.UserRepo;
import org.itstep.webapp.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@EnableWebSecurity
public class UserServiceImpl implements UserService {
    private final UserRepo userRepo;


    public UserServiceImpl(UserRepo repository) {
        this.userRepo = repository;
    }

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;


    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {

        DbUser dbUser = userRepo.findByEmail(email);
        if(dbUser != null) {
            User user = new User(dbUser.getEmail(), dbUser.getPassword(),dbUser.getRoles());
            return user;
        }
        return null;
    }
    @Override
    public List<DbUser> getUser() {
        return userRepo.findAll();
    }

    @Override public DbUser registerUser(final DbUser user) {

        DbUser checkUser = userRepo.findByEmail(user.getEmail());
        if (checkUser == null){
            user.setPassword(passwordEncoder.encode(user.getPassword()));
            return userRepo.save(user);
        }
        return null;
    }


}
