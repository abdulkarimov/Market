package org.itstep.webapp.repository;

import org.itstep.webapp.entity.DbItem;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface  itemRepository  extends JpaRepository<DbItem, Long> {

List <DbItem> findByNameLike(String name);//contains
    Page <DbItem> findAllByName(String name,Pageable pageable);

}
