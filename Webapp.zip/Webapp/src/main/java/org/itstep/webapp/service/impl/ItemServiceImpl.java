package org.itstep.webapp.service.impl;

import org.itstep.webapp.entity.DbItem;
import org.itstep.webapp.repository.itemRepository;
import org.itstep.webapp.service.ItemService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
@Transactional
public class ItemServiceImpl implements ItemService {

    private final itemRepository repository;

    public ItemServiceImpl(itemRepository repository) {
        this.repository = repository;
    }


    @Override
    public Page<DbItem> getAllItems(final  int currentPage, final int size) {
        Pageable pageable = PageRequest.of(currentPage,size);
        return repository.findAll(pageable);
    }

    @Override
    public Page<DbItem> getAllItemsByName(int currentPage, int size, String name) {
        Pageable pageable = PageRequest.of(currentPage,size);
        return repository.findAllByName(name,pageable);
    }


    @Override
    public void saveItem(DbItem item) {
        repository.save(item);
    }

    @Override
    public Long getItemsCount() {
        return repository.count();
    }

    @Override
    public List<DbItem> getItemByName(String name) {
        return repository.findByNameLike(name);
    }

    @Override
    public void deleteItem(Long id) {
        repository.deleteById(id);
    }


}
