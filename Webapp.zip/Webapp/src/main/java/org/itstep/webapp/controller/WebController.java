package org.itstep.webapp.controller;

import org.apache.commons.codec.digest.DigestUtils;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.itstep.webapp.config.StaticConfig;
import org.itstep.webapp.entity.DbItem;
import org.itstep.webapp.entity.DbUser;
import org.itstep.webapp.entity.Role;
import org.itstep.webapp.repository.UserRepo;
import org.itstep.webapp.service.ItemService;
import org.itstep.webapp.service.UserService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.domain.Page;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

@Controller
@Slf4j
public class WebController {

    @Value("${file.upload.ava}")
    private String avaBaseUrl;

    @Value("${file.upload.defclasspath}")
    private String defaultAvaClasspath;

    @Value("${file.upload.avaclasspath}")
    private String avaClasspath;


    private final ItemService itemService;
    private final UserService userService;
    private final UserRepo userRepo;

    public WebController(ItemService itemService, UserService userService, UserRepo userRepo) {
        this.itemService = itemService;
        this.userService = userService;
        this.userRepo = userRepo;
    }

    @GetMapping(value = {"/", "index", "home"})
    public String index(Model model,
                        @RequestParam(name = "page", defaultValue = "1") int page) {

        model.addAttribute("currentUser", getUser());


        int finalPage = page - 1;

        if (finalPage < 0) {
            finalPage = 0;
        }

        Long ItemCount = itemService.getItemsCount();

        Long pageCount = (ItemCount - 1) / StaticConfig.PAGE_SIZE + 1;

        if (pageCount < 1) {
            pageCount = 1l;
        }

        Page<DbItem> allItems = itemService.getAllItems(finalPage, StaticConfig.PAGE_SIZE);


        model.addAttribute("item", allItems);
        model.addAttribute("pageCount", pageCount);


        return "index";
    }


    @GetMapping(value = "/login")
    public String login(Model model) {

        model.addAttribute("currentUser", getUser());
        return "login";
    }




    @GetMapping(value = "/admin")
    public String admin(Model model) {

        model.addAttribute("currentUser", getUser());
        return "admin";
    }

    @GetMapping(value = "/register")
    public String register(Model model) {

        model.addAttribute("currentUser", getUser());
        return "register";
    }


    @PostMapping(value = "/buy")
    public String buy(Model model,
                          @RequestParam(name = "id") String id) {

        model.addAttribute("currentUser", getUser());


        Long ID = Long.valueOf(id);


        itemService.deleteItem(ID);


        return "redirect:/index";
    }




    @PostMapping(value = "adduser")
    public String addUser(Model model,
                          @RequestParam(name = "email") String email,
                          @RequestParam(name = "password") String password,
                          @RequestParam(name = "confirm_password") String confirmPass,
                          @RequestParam(name = "full_name") String fullName) {

        model.addAttribute("currentUser", getUser());

        if (password.equals(confirmPass)) {
            List<Role> roles = new ArrayList<>();
            roles.add(StaticConfig.ROLE_USER);

            DbUser user = new DbUser(null, email, password, fullName, null, roles);
            if (userService.registerUser(user) != null) {
                return "redirect:/login";
            }
        }
        return "/index";
    }


    @GetMapping(value = "accessdenied")
    public String accessdenied(Model model) {
        model.addAttribute("currentUser", getUser());

        return "403";
    }


    private DbUser getUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (!(authentication instanceof AnonymousAuthenticationToken)) {
            User user = (User) authentication.getPrincipal();
            DbUser dbUser = userRepo.findByEmail(user.getUsername());
            return dbUser;
        }
        return null;
    }


    @GetMapping(value = "viewprofilephoto/{avaHash}",
            produces = {MediaType.IMAGE_JPEG_VALUE, MediaType.IMAGE_PNG_VALUE})
    public @ResponseBody
    byte[] viewProfilePhoto(
            @PathVariable(name = "avaHash") String avaHash) throws IOException {

        String image = defaultAvaClasspath + "img.png";

        if (!avaHash.equals("null")) {
            image = avaClasspath + avaHash;
        }


        InputStream in;

        try {
            ClassPathResource classPathResource = new ClassPathResource(image);
            in = classPathResource.getInputStream();
        } catch (IOException e) {

            image = defaultAvaClasspath + "img.png";
            ClassPathResource classPathResource = new ClassPathResource(image);
            in = classPathResource.getInputStream();
            log.error(e.getMessage());
            e.printStackTrace();
        }
        return IOUtils.toByteArray(in);
    }


    @PreAuthorize("hasAnyRole('ROLE_USER')")
    @PostMapping(value = "uploadava")
    public String uploadAvatar(Model model,
                               @RequestParam(name = "file_ava") MultipartFile file,
                               @RequestParam(name = "name") String name,
                               @RequestParam(name = "price") Integer price,
                               @RequestParam(name = "description") String description

    ) {

        DbUser user = getUser();
        DbItem item = new DbItem();
        item.setName(name);
        item.setPrice(price);
        item.setDescription(description);
        item.setUser(user);


        if (file.getContentType().equals("image/png") || file.getContentType().equals("image/jpeg")) {

            String uniqueName = DigestUtils.sha1Hex("user_ava_" + item.getName());

            String ext = "png";

            if (file.getContentType().equals("image/jpeg")) {
                ext = "jpg";
            }

            try {

                String fullPath = avaBaseUrl + uniqueName + "." + ext;
                byte[] bytes = file.getBytes();
                Path path = Paths.get(fullPath);
                Files.write(path, bytes);
                item.setAva(fullPath);
                item.setAvaHash(uniqueName + "." + ext);
                itemService.saveItem(item);

            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }


        return "redirect:/";
    }


    @GetMapping(value = "search")
    public String search(Model model, @RequestParam(name = "name", defaultValue = "", required = false) String name) {

        model.addAttribute("currentUser", getUser());
        List<DbItem> Item = itemService.getItemByName("%"+name+"%");

        model.addAttribute("item", Item);

        System.out.println(Item.toString());

        model.addAttribute("name",name);

        return "search";
    }


}