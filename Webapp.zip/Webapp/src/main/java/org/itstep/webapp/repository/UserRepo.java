package org.itstep.webapp.repository;

import org.itstep.webapp.entity.DbUser;
import org.itstep.webapp.entity.Role;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserRepo extends JpaRepository<DbUser,Long> {
    DbUser findByEmail(String email);

    List<DbUser> findAllByRolesContains(Role role, Pageable pageable);

}
