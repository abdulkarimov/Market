package org.itstep.webapp.service;

import org.itstep.webapp.entity.DbItem;
import org.springframework.data.domain.Page;

import java.util.List;

public interface ItemService {
    Page<DbItem> getAllItems(final  int currentPage, final int size);
    Page<DbItem> getAllItemsByName(final  int currentPage, final int size,String name);
    void saveItem(DbItem item);
    Long getItemsCount();
    List<DbItem> getItemByName(String name);
    void deleteItem(Long id);

}
